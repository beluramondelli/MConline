﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class Login1
    {
        public string username;
        public string password;

        public Login1(string user, string pass)
        {
            this.username = user;
            this.password = pass;
        }

    }
}
